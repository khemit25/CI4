-- phpMyAdmin SQL Dump
-- version 4.9.0.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Sep 30, 2020 at 05:45 PM
-- Server version: 10.4.6-MariaDB
-- PHP Version: 7.3.8

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `ci4`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin_login`
--

CREATE TABLE `admin_login` (
  `id` int(5) UNSIGNED NOT NULL,
  `username` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `token` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `admin_setting`
--

CREATE TABLE `admin_setting` (
  `id` int(5) UNSIGNED NOT NULL,
  `type` varchar(10) DEFAULT NULL,
  `informail` varchar(20) DEFAULT NULL,
  `infophone` bigint(10) DEFAULT NULL,
  `supportmail` varchar(20) DEFAULT NULL,
  `copywrite` text DEFAULT NULL,
  `image` varchar(100) DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `admin_setting`
--

INSERT INTO `admin_setting` (`id`, `type`, `informail`, `infophone`, `supportmail`, `copywrite`, `image`, `updated_at`) VALUES
(1, 'header_upd', 'anil@gmail.com', 1234567890, NULL, NULL, 'cc1.jpg', '2020-08-25 00:53:31');

-- --------------------------------------------------------

--
-- Table structure for table `client_table`
--

CREATE TABLE `client_table` (
  `id` int(11) NOT NULL,
  `owner` varchar(255) DEFAULT NULL,
  `airbnb` varchar(255) DEFAULT NULL,
  `property_type` varchar(50) DEFAULT NULL,
  `country` varchar(255) DEFAULT NULL,
  `street_address` varchar(255) DEFAULT NULL,
  `suite` varchar(255) DEFAULT NULL,
  `city` varchar(255) DEFAULT NULL,
  `state` varchar(255) DEFAULT NULL,
  `Postcode` varchar(255) DEFAULT NULL,
  `date` date DEFAULT NULL,
  `compulsory_inclusions` varchar(255) DEFAULT NULL,
  `guest` varchar(50) DEFAULT NULL,
  `bedrooms` varchar(50) DEFAULT NULL,
  `bathrooms` varchar(50) DEFAULT NULL,
  `king` varchar(50) DEFAULT NULL,
  `queen` varchar(50) DEFAULT NULL,
  `double` varchar(50) DEFAULT NULL,
  `single` varchar(50) DEFAULT NULL,
  `sofa` varchar(50) DEFAULT NULL,
  `bunk` varchar(50) DEFAULT NULL,
  `mstes` varchar(50) DEFAULT NULL,
  `couch` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `client_table`
--

INSERT INTO `client_table` (`id`, `owner`, `airbnb`, `property_type`, `country`, `street_address`, `suite`, `city`, `state`, `Postcode`, `date`, `compulsory_inclusions`, `guest`, `bedrooms`, `bathrooms`, `king`, `queen`, `double`, `single`, `sofa`, `bunk`, `mstes`, `couch`) VALUES
(11, '534534534534', 'terterter', 'Town', 'India', '4444', '5555', '666', '777', '888', '2069-04-09', NULL, '2', '3', '4', '5', '6', '7', '8', '9', '10', '11', '12');

-- --------------------------------------------------------

--
-- Table structure for table `compulsory_inclusions`
--

CREATE TABLE `compulsory_inclusions` (
  `id` int(11) NOT NULL,
  `name` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `compulsory_inclusions`
--

INSERT INTO `compulsory_inclusions` (`id`, `name`) VALUES
(1, 'fire blanket'),
(2, 'first_add'),
(3, 'smoke dector'),
(4, 'vacume'),
(5, 'mop'),
(6, 'bucket');

-- --------------------------------------------------------

--
-- Table structure for table `country`
--

CREATE TABLE `country` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `country`
--

INSERT INTO `country` (`id`, `name`) VALUES
(1, 'Albania'),
(2, 'Algeria'),
(3, 'Angola'),
(4, 'Brazil'),
(5, 'Brunei'),
(6, 'Bulgaria'),
(7, 'Burkina Faso'),
(8, 'Chile'),
(9, 'China'),
(10, 'Colombia'),
(11, 'Cuba'),
(12, 'Cyprus'),
(13, 'Czechia '),
(14, 'Dominica'),
(15, 'Ecuador'),
(16, 'India'),
(17, 'Indonesia'),
(18, 'Iran'),
(19, 'Iraq'),
(20, 'Ireland'),
(21, 'Israel'),
(22, 'Italy');

-- --------------------------------------------------------

--
-- Table structure for table `migrations`
--

CREATE TABLE `migrations` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `version` varchar(255) NOT NULL,
  `class` text NOT NULL,
  `group` varchar(255) NOT NULL,
  `namespace` varchar(255) NOT NULL,
  `time` int(11) NOT NULL,
  `batch` int(11) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `migrations`
--

INSERT INTO `migrations` (`id`, `version`, `class`, `group`, `namespace`, `time`, `batch`) VALUES
(9, '2020-08-18-065647', 'App\\Database\\Migrations\\AdminLogin', 'default', 'App', 1598331668, 1),
(10, '2020-08-25-044752', 'App\\Database\\Migrations\\AdminSetting', 'default', 'App', 1598331668, 1);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin_login`
--
ALTER TABLE `admin_login`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `admin_setting`
--
ALTER TABLE `admin_setting`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `client_table`
--
ALTER TABLE `client_table`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `compulsory_inclusions`
--
ALTER TABLE `compulsory_inclusions`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `country`
--
ALTER TABLE `country`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `migrations`
--
ALTER TABLE `migrations`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin_login`
--
ALTER TABLE `admin_login`
  MODIFY `id` int(5) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `admin_setting`
--
ALTER TABLE `admin_setting`
  MODIFY `id` int(5) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `client_table`
--
ALTER TABLE `client_table`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `compulsory_inclusions`
--
ALTER TABLE `compulsory_inclusions`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `country`
--
ALTER TABLE `country`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=23;

--
-- AUTO_INCREMENT for table `migrations`
--
ALTER TABLE `migrations`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
